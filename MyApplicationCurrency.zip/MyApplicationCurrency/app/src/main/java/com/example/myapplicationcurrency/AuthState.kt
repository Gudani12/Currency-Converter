package com.example.myapplicationcurrency


import com.google.firebase.auth.FirebaseUser


data class AuthState(
    val isLoading: Boolean = false,
    val isAuthenticated: Boolean = false,
    val error: String? = null
)