package com.example.myapplicationcurrency


import java.util.Date

data class ConversionHistory(
    val id: String? = null,
    val fromCurrency: String,
    val toCurrency: String,
    val amount: Double,
    val result: Double,
    val timestamp: Date = Date(),
    val isSynced: Boolean = false
)