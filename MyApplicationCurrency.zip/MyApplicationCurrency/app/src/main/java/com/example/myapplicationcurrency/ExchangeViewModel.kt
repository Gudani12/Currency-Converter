package com.example.myapplicationcurrency


import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Date
import java.util.UUID

class ExchangeViewModel : ViewModel() {

    private val _conversionResult = MutableStateFlow("")
    val conversionResult: StateFlow<String> = _conversionResult.asStateFlow()

    private val _isLoading = MutableStateFlow(false)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _errorMessage = MutableStateFlow<String?>(null)
    val errorMessage: StateFlow<String?> = _errorMessage.asStateFlow()

    private val _conversionHistory = MutableStateFlow<List<ConversionHistory>>(emptyList())
    val conversionHistory: StateFlow<List<ConversionHistory>> = _conversionHistory.asStateFlow()

    // Static exchange rates for offline functionality
    private val exchangeRates = mapOf(
        "USD" to 1.0,
        "EUR" to 0.85,
        "GBP" to 0.73,
        "ZAR" to 18.5,
        "JPY" to 110.0,
        "AUD" to 1.35,
        "CAD" to 1.25,
        "CHF" to 0.92,
        "CNY" to 6.45,
        "INR" to 75.0
    )

    val supportedCurrencies = listOf(
        Currency("US Dollar", "USD", "$"),
        Currency("Euro", "EUR", "€"),
        Currency("British Pound", "GBP", "£"),
        Currency("South African Rand", "ZAR", "R"),
        Currency("Japanese Yen", "JPY", "¥"),
        Currency("Australian Dollar", "AUD", "A$"),
        Currency("Canadian Dollar", "CAD", "C$"),
        Currency("Swiss Franc", "CHF", "CHF"),
        Currency("Chinese Yuan", "CNY", "¥"),
        Currency("Indian Rupee", "INR", "₹")
    )

    fun convert(fromCurrency: String, toCurrency: String, amount: String, userId: String) {
        if (amount.isBlank()) {
            _errorMessage.value = "Please enter an amount"
            return
        }

        val amountDouble = amount.toDoubleOrNull()
        if (amountDouble == null) {
            _errorMessage.value = "Please enter a valid amount"
            return
        }

        _isLoading.value = true
        _errorMessage.value = null

        viewModelScope.launch {
            try {
                val result = performConversion(fromCurrency, toCurrency, amountDouble)
                _conversionResult.value = String.format("%.2f", result)

                // Save to history
                val conversion = ConversionHistory(
                    id = UUID.randomUUID().toString(),
                    fromCurrency = fromCurrency,
                    toCurrency = toCurrency,
                    amount = amountDouble,
                    result = result,
                    timestamp = Date()
                )
                _conversionHistory.value = _conversionHistory.value + conversion

            } catch (e: Exception) {
                _errorMessage.value = "Conversion failed: ${e.message}"
            } finally {
                _isLoading.value = false
            }
        }
    }

    private fun performConversion(fromCurrency: String, toCurrency: String, amount: Double): Double {
        val fromRate = exchangeRates[fromCurrency] ?: throw IllegalArgumentException("Unsupported currency: $fromCurrency")
        val toRate = exchangeRates[toCurrency] ?: throw IllegalArgumentException("Unsupported currency: $toCurrency")

        // Convert via USD as base currency
        val amountInUsd = amount / fromRate
        return amountInUsd * toRate
    }

    fun syncOfflineData() {
        viewModelScope.launch {
            val unsyncedConversions = _conversionHistory.value.filter { !it.isSynced }
            if (unsyncedConversions.isNotEmpty()) {
                // Simulate sync with remote server
                _conversionHistory.value = _conversionHistory.value.map { it.copy(isSynced = true) }
            }
        }
    }

    fun clearHistory() {
        _conversionHistory.value = emptyList()
    }

    fun clearError() {
        _errorMessage.value = null
    }

    fun clearResult() {
        _conversionResult.value = ""
    }
}