package com.example.myapplicationcurrency


import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class AuthViewModel : ViewModel() {
    private val _authState = MutableStateFlow(AuthState())
    val authState: StateFlow<AuthState> = _authState.asStateFlow()

    init {
        checkCurrentUser()
    }

    private fun checkCurrentUser() {
        _authState.value = _authState.value.copy(isLoading = true)
        // Simulate checking user
        viewModelScope.launch {
            delay(1000) // Simulate network delay
            _authState.value = _authState.value.copy(
                isLoading = false,
                isAuthenticated = false // Start with no user for testing
            )
        }
    }

    suspend fun login(email: String, password: String): Result<Unit> {
        return try {
            _authState.value = _authState.value.copy(isLoading = true)
            // Simulate login process
            delay(1500)

            // Simple validation for demo
            if (email.isNotEmpty() && password.isNotEmpty()) {
                _authState.value = _authState.value.copy(
                    isLoading = false,
                    isAuthenticated = true
                )
                Result.success(Unit)
            } else {
                _authState.value = _authState.value.copy(
                    isLoading = false,
                    error = "Please enter email and password"
                )
                Result.failure(Exception("Invalid credentials"))
            }
        } catch (e: Exception) {
            _authState.value = _authState.value.copy(
                isLoading = false,
                error = e.message ?: "Login failed"
            )
            Result.failure(e)
        }
    }

    suspend fun register(email: String, password: String): Result<Unit> {
        return try {
            _authState.value = _authState.value.copy(isLoading = true)
            // Simulate registration process
            delay(1500)

            // Simple validation for demo
            if (email.isNotEmpty() && password.length >= 6) {
                _authState.value = _authState.value.copy(isLoading = false)
                Result.success(Unit)
            } else {
                _authState.value = _authState.value.copy(
                    isLoading = false,
                    error = "Password must be at least 6 characters"
                )
                Result.failure(Exception("Invalid registration"))
            }
        } catch (e: Exception) {
            _authState.value = _authState.value.copy(
                isLoading = false,
                error = e.message ?: "Registration failed"
            )
            Result.failure(e)
        }
    }

    fun logout() {
        _authState.value = AuthState()
    }

    fun clearError() {
        _authState.value = _authState.value.copy(error = null)
    }
}