package com.example.myapplicationcurrency

import androidx.navigation.compose.rememberNavController


import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable

@Composable
fun AppNavigation() {
    val navController = rememberNavController()
    val authViewModel: AuthViewModel = hiltViewModel()
    val authState by authViewModel.authState.collectAsStateWithLifecycle()

    LaunchedEffect(authState.isAuthenticated) {
        if (authState.isAuthenticated) {
            navController.navigate(Screens.MainScreen.route) {
                popUpTo(Screens.SplashScreen.route) { inclusive = true }
            }
        } else if (!authState.isLoading) {
            navController.navigate(Screens.LoginScreen.route) {
                popUpTo(Screens.SplashScreen.route) { inclusive = true }
            }
        }
    }

    NavHost(
        navController = navController,
        startDestination = Screens.SplashScreen.route
    ) {
        composable(Screens.SplashScreen.route) {
            SplashScreen()
        }
        composable(Screens.LoginScreen.route) {
            LoginScreen(
                onLoginSuccess = { navController.navigate(Screens.MainScreen.route) },
                onNavigateToRegister = { navController.navigate(Screens.RegisterScreen.route) }
            )
        }
        composable(Screens.RegisterScreen.route) {
            RegisterScreen(
                onRegisterSuccess = { navController.navigate(Screens.LoginScreen.route) },
                onNavigateToLogin = { navController.popBackStack() }
            )
        }
        composable(Screens.MainScreen.route) {
            MainScreen(
                onLogout = {
                    authViewModel.logout()
                    navController.navigate(Screens.LoginScreen.route)
                },
                onNavigateToSettings = { navController.navigate(Screens.SettingsScreen.route) }
            )
        }
        composable(Screens.SettingsScreen.route) {
            SettingsScreen(onNavigateBack = { navController.popBackStack() })
        }
    }
}