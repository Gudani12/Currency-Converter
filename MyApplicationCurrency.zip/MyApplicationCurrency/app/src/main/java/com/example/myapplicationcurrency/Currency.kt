package com.example.myapplicationcurrency

data class Currency(
    val name: String,
    val code: String,
    val symbol: String = ""
) {
    override fun toString(): String = "$name ($code)"
}