package com.example.myapplicationcurrency


import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.ExposedDropdownMenuBox
import androidx.compose.material3.ExposedDropdownMenuDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.hilt.navigation.compose.hiltViewModel
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import kotlinx.coroutines.launch

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainScreen(
    onLogout: () -> Unit,
    onNavigateToSettings: () -> Unit,
    exchangeViewModel: ExchangeViewModel = hiltViewModel()
) {
    var amount by remember { mutableStateOf("") }
    var fromCurrency by remember { mutableStateOf<Currency?>(null) }
    var toCurrency by remember { mutableStateOf<Currency?>(null) }
    var showFromCurrencyMenu by remember { mutableStateOf(false) }
    var showToCurrencyMenu by remember { mutableStateOf(false) }

    val conversionResult by exchangeViewModel.conversionResult.collectAsStateWithLifecycle()
    val isLoading by exchangeViewModel.isLoading.collectAsStateWithLifecycle()
    val errorMessage by exchangeViewModel.errorMessage.collectAsStateWithLifecycle()
    val conversionHistory by exchangeViewModel.conversionHistory.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    // Set default currencies
    LaunchedEffect(Unit) {
        fromCurrency = exchangeViewModel.supportedCurrencies.find { it.code == "USD" }
        toCurrency = exchangeViewModel.supportedCurrencies.find { it.code == "ZAR" }
    }

    // Show error messages
    LaunchedEffect(errorMessage) {
        errorMessage?.let { error ->
            scope.launch {
                snackbarHostState.showSnackbar(error)
                exchangeViewModel.clearError()
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("QuickConverter") },
                actions = {
                    IconButton(onClick = {
                        exchangeViewModel.syncOfflineData()
                        scope.launch {
                            snackbarHostState.showSnackbar("Data synced successfully")
                        }
                    }) {
                        Icon(Icons.Default.Refresh, contentDescription = "Sync")
                    }
                    IconButton(onClick = {
                        showConversionHistory(conversionHistory, scope, snackbarHostState)
                    }) {
                        Icon(Icons.Default.History, contentDescription = "History")
                    }
                    IconButton(onClick = onNavigateToSettings) {
                        Icon(Icons.Default.Settings, contentDescription = "Settings")
                    }
                    IconButton(onClick = onLogout) {
                        Icon(Icons.Default.AccountCircle, contentDescription = "Logout")
                    }
                }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(24.dp)
                .verticalScroll(rememberScrollState()),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Currency Selection Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // From Currency Dropdown
                Column(modifier = Modifier.weight(1f)) {
                    Text("From Currency", style = MaterialTheme.typography.labelMedium)
                    Spacer(modifier = Modifier.height(8.dp))
                    CurrencyDropdown(
                        currencies = exchangeViewModel.supportedCurrencies,
                        selectedCurrency = fromCurrency,
                        onCurrencySelected = { fromCurrency = it },
                        expanded = showFromCurrencyMenu,
                        onExpandedChange = { showFromCurrencyMenu = it },
                        label = "Select currency"
                    )
                }

                // To Currency Dropdown
                Column(modifier = Modifier.weight(1f)) {
                    Text("To Currency", style = MaterialTheme.typography.labelMedium)
                    Spacer(modifier = Modifier.height(8.dp))
                    CurrencyDropdown(
                        currencies = exchangeViewModel.supportedCurrencies,
                        selectedCurrency = toCurrency,
                        onCurrencySelected = { toCurrency = it },
                        expanded = showToCurrencyMenu,
                        onExpandedChange = { showToCurrencyMenu = it },
                        label = "Select currency"
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            // Amount Input
            OutlinedTextField(
                value = amount,
                onValueChange = { amount = it },
                label = { Text("Amount") },
                modifier = Modifier.fillMaxWidth(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Convert Button
            Button(
                onClick = {
                    if (fromCurrency == null || toCurrency == null) {
                        scope.launch {
                            snackbarHostState.showSnackbar("Please select both currencies")
                        }
                        return@Button
                    }
                    exchangeViewModel.convert(
                        fromCurrency!!.code,
                        toCurrency!!.code,
                        amount,
                        "current_user"
                    )
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = amount.isNotEmpty() && fromCurrency != null && toCurrency != null && !isLoading
            ) {
                if (isLoading) {
                    CircularProgressIndicator(
                        modifier = Modifier.width(16.dp).height(16.dp),
                        strokeWidth = 2.dp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Converting...")
                } else {
                    Text("Convert")
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Clear Button
            Button(
                onClick = {
                    amount = ""
                    exchangeViewModel.clearResult()
                },
                modifier = Modifier.fillMaxWidth(),
                enabled = amount.isNotEmpty() || conversionResult.isNotEmpty()
            ) {
                Text("Clear")
            }

            Spacer(modifier = Modifier.height(32.dp))

            // Result Card
            if (conversionResult.isNotEmpty()) {
                Card(
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(
                            text = "Conversion Result",
                            style = MaterialTheme.typography.titleMedium
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "$amount ${fromCurrency?.code} = $conversionResult ${toCurrency?.code}",
                            style = MaterialTheme.typography.headlineMedium,
                            color = MaterialTheme.colorScheme.primary
                        )
                    }
                }
            }

            // Quick Actions
            Spacer(modifier = Modifier.height(32.dp))
            Text("Quick Actions", style = MaterialTheme.typography.titleMedium)
            Spacer(modifier = Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                Button(
                    onClick = {
                        fromCurrency = exchangeViewModel.supportedCurrencies.find { it.code == "USD" }
                        toCurrency = exchangeViewModel.supportedCurrencies.find { it.code == "EUR" }
                        amount = "100"
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("USD → EUR")
                }
                Button(
                    onClick = {
                        fromCurrency = exchangeViewModel.supportedCurrencies.find { it.code == "EUR" }
                        toCurrency = exchangeViewModel.supportedCurrencies.find { it.code == "ZAR" }
                        amount = "50"
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text("EUR → ZAR")
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CurrencyDropdown(
    currencies: List<Currency>,
    selectedCurrency: Currency?,
    onCurrencySelected: (Currency) -> Unit,
    expanded: Boolean,
    onExpandedChange: (Boolean) -> Unit,
    label: String
) {
    ExposedDropdownMenuBox(
        expanded = expanded,
        onExpandedChange = onExpandedChange
    ) {
        OutlinedTextField(
            value = selectedCurrency?.name ?: "",
            onValueChange = {},
            readOnly = true,
            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expanded) },
            modifier = Modifier
                .fillMaxWidth()
                .menuAnchor(),
            label = { Text(label) },
            singleLine = true
        )
        ExposedDropdownMenu(
            expanded = expanded,
            onDismissRequest = { onExpandedChange(false) }
        ) {
            currencies.forEach { currency ->
                DropdownMenuItem(
                    text = { Text("${currency.name} (${currency.code})") },
                    onClick = {
                        onCurrencySelected(currency)
                        onExpandedChange(false)
                    }
                )
            }
        }
    }
}

private fun showConversionHistory(
    history: List<ConversionHistory>,
    scope: kotlinx.coroutines.CoroutineScope,
    snackbarHostState: androidx.compose.material3.SnackbarHostState
) {
    if (history.isEmpty()) {
        scope.launch {
            snackbarHostState.showSnackbar("No conversion history")
        }
        return
    }

    val recentHistory = history.take(5).joinToString("\n") { conversion ->
        "${conversion.amount} ${conversion.fromCurrency} → ${conversion.result} ${conversion.toCurrency}"
    }

    scope.launch {
        snackbarHostState.showSnackbar("Recent conversions:\n$recentHistory")
    }
}

@Preview
@Composable
fun MainScreenPreview() {
    MainScreen(
        onLogout = {},
        onNavigateToSettings = {}
    )
}